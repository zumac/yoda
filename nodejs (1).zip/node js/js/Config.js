exports.properties = {
  baseURL : 'https://developer.api.yodlee.com/ysl/restserver/v1/',
 cobrandParam : {
    "cobrand":      {
      "cobrandLogin": "sbCobXXX",
      "cobrandPassword": "XXX",
      "locale": "en_US"
     }
},
	userParam: {
    "user":      {
      "loginName": "sbMemXXX",
      "password": "sbMemXXX#123",
      "locale": "en_US"
     }
},

		
}
		
